<?php
/**
 * The template for displaying Achive(s)category
 *
 */
	get_template_part("archive", "page");
?>