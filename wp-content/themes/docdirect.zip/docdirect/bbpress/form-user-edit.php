<?php

/**
 * bbPress User Profile Edit Part
 *
 * @package bbPress
 * @subpackage Theme
 */

?>
<?php esc_html_e('Oops! Edit Profile is disbaled by admin. You can update your profile from your dashboard.','docdirect');?>
