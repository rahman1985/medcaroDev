<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$manifest = array();
$manifest['id'] = 'docdirect';
$manifest['supported_extensions'] = array(
	'page-builder' 	=> array(),
	'backups' 		 => array(),
	'sidebars' 		=> array(),
	'breadcrumbs'  	 => array(),
	'seo' 			 => array(),
	'analytics' 	   => array(),
);