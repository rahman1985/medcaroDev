<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => esc_html__( 'Skill Set', 'docdirect' ),
	'description' => esc_html__( 'Add Your Skill Set', 'docdirect' ),
	'tab'         => esc_html__( 'DocDirect', 'docdirect' ),
);